require("dotenv").config();
const express=require("express");
const session=require("express-session");
const mongoStore=require("connect-mongo");
const userRoutes = require("./routes/users/users");
const globalErrHandler = require("./middlewares/globalErrHandler");
require("./config/dbConnect");
const app=express();




//middlewares

app.use(express.json());

//session config
app.use(session({
    secret:process.env.SECRET_KEY,
    resave:false,
    saveUninitialized:true,
    store:new mongoStore({
        mongoUrl:process.env.MONGO_URL,
        ttl:24*60*60*7  //7day
    })
}))


//-------
//users Route
//-------
app.use("/api/v1/users",userRoutes);




//ErrorHandler middleware
app.use(globalErrHandler);

//listen server
const PORT=process.env.PORT || 3000;
app.listen(PORT,()=>{
    console.log(`server is running.... on PORT ${PORT}`);
})