const bcrypt=require("bcryptjs");
const User = require("../../models/user/User");
const appErr = require("../../utils/appErr");



const registerCtrl=async(req,res,next)=>{
   
   const{fullname, email,password}=req.body;
      //check if field is empty
      if(!fullname || !email || !password){
         return next(appErr("All fields are required"))
      }
    try {
      //1.Check if user exist
      const userFound=await User.findOne({email});
      //2.throw an error
      if(userFound){
         return next(appErr("User already exists"))
      }else{
         //3.Hash password
         const salt=await bcrypt.genSalt(10);
         const hashedPassword=await bcrypt.hash(password,salt);
          //4.create user
         const user=await User.create({
            fullname, email,password:hashedPassword
         })
          res.json({
           status:"sucess",
           data:user,
          }) 
      }
   } catch (error) {
       console.log(error);
    }
}

const loginCtrl=async(req,res,next)=>{
   const{email,password}=req.body;
   if(!email || !password){
      return next(appErr("all fields are required"))
   }

    try {
      //check if email exist
      const userFound=await User.findOne({email});
      if(!userFound){
        return next(appErr("Invalid login credentials"))
      }

      //verify password
      const isPasswordValid=await bcrypt.compare(password,userFound.password);
      if(!isPasswordValid){
         return next(appErr("Invalid login credentials"))
      }
      //save the user into
      req.session.userAuth=userFound._id;
      
       res.json({
        status:"sucess",
        data:userFound
       }) 
    } catch (error) {
       console.log(error);
    }
}

const userDetailsCtrl=async(req,res)=>{
   
    try {
      //get user id from params
      const userID=req.params.id;
      //find the user
      const user=await User.findById(userID);
       res.json({
        status:"sucess",
        user:user,
       }) 
    } catch (error) {
       console.log(error);
    }
}

const profileCtrl=async(req,res)=>{
    try {
      //get the login user
      const userID=req.session.userAuth;

      //find the user
      const userFound=await User.findById(userID).populate("posts").populate("comments");
       res.json({
        status:"sucess",
        user:userFound,
       }) 
    } catch (error) {
       console.log(error);
    }
}

const uploadProflePhoto=async(req,res,next)=>{
   
    try {
      //1.find the user to be updated
      const userId=req.session.userAuth;
      const userFound=await User.findById(userId);
      //2.check if user is found
      if(!userFound){
         return next(appErr("user not found",403))
      }
      //3.update profile photo
      await User.findByIdAndUpdate(userId,{
         profileIMage:req.file.path
      },{
         new:true,
      })
       res.json({
        status:"sucess",
        data:"You have successfully updated your profile photo"
       }) 
    } catch (error) {
      next(appErr(error.message))
    }
}

const coverProfilePhoto=async(req,res)=>{
   try {
      //1.find the user to be updated
      const userId=req.session.userAuth;
      const userFound=await User.findById(userId);
      //2.check if user is found
      if(!userFound){
         return next(appErr("user not found",403))
      }
      //3.update profile photo
      await User.findByIdAndUpdate(userId,{
         coverIMage:req.file.path
      },{
         new:true,
      })
       res.json({
        status:"sucess",
        data:"You have successfully updated your cover photo"
       }) 
    } catch (error) {
       console.log(error);
    }
}

const updatePasswordCtrl=async(req,res,next)=>{
   const{password}=req.body;
    try {
      //check if user is updating password
      if(password){
         const salt=await bcrypt.genSalt(10);
         const hashedPassword=await bcrypt.hash(password,salt);
         //update user
         await User.findByIdAndUpdate(req.params.id,{
            password:hashedPassword
         },{
            new:true,
         })
          res.json({
           status:"sucess",
           user:"User password has been changed successfully"
          }) 
      }
      
      
    } catch (error) {
       return next(appErr("Please provide password field"))
    }
}

const updateUserCtrl=async(req,res,next)=>{
   const{fullname,email}=req.body;

    try {
      //check if email is not taken
      if(email){
         const emailTaken=await User.findOne({email});
         if(emailTaken){
            return next(appErr("Email is taken",400));
         }
      }
      //update user
      const user=await User.findByIdAndUpdate(req.params.id,{
         fullname,email
      },{
         new:true,
      })

       res.json({
        status:"sucess",
        data:user,
       }) 
    } catch (error) {
       return res.json(next(appErr(error.message)));
    }
}

const logoutCtrl=async(req,res)=>{
    try {
       res.json({
        status:"sucess",
        user:"User logout"
       }) 
    } catch (error) {
       console.log(error);
    }
}

module.exports={registerCtrl,loginCtrl,userDetailsCtrl,profileCtrl,uploadProflePhoto,coverProfilePhoto,updatePasswordCtrl,updateUserCtrl,logoutCtrl};