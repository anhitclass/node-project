const { default: mongoose } = require("mongoose");


//schema
const userSchema=new mongoose.Schema({
    fullname:{
        type:String,
        required:true,
    },
    email:{
        type:String,
        required:true,
    },
    password:{
        type:String,
        required:true,
    },
    profileIMage:{
        type:String,
    },
    coverIMage:{
        type:String,
    },
    
},
{
    timestamps:true,
})

//compile to the schema to form a model
const User=mongoose.model("User",userSchema);

module.exports=User;
